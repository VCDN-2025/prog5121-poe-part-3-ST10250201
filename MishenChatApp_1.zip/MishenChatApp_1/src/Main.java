import javax.swing.*;
import java.util.HashMap;

public class Main {

    // Simple in-memory user store (username -> password)
    private static final HashMap<String, String> users = new HashMap<>();

    public static void main(String[] args) {

        // Load stored messages at start
        MessageHandler.readFromJSON("storedMessages.json");

        // Show welcome screen for login or register
        while (true) {
            String option = JOptionPane.showInputDialog("""
                                                        Welcome!
                                                        1. Register
                                                        2. Login
                                                        3. Exit""");

            if (option == null || option.equals("3")) {
                JOptionPane.showMessageDialog(null, "Goodbye!");
                break;
            }

            switch (option) {
                case "1" -> registerUser();
                case "2" -> {
                    boolean loggedIn = loginUser();
                    if (loggedIn) {
                        showMessageMenu();
                    }
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
    }

    private static void registerUser() {
        String username = JOptionPane.showInputDialog("Enter new username:");
        if (username == null || username.isBlank()) {
            JOptionPane.showMessageDialog(null, "Username cannot be empty.");
            return;
        }
        if (users.containsKey(username)) {
            JOptionPane.showMessageDialog(null, "Username already taken.");
            return;
        }
        String password = JOptionPane.showInputDialog("Enter new password:");
        if (password == null || password.isBlank()) {
            JOptionPane.showMessageDialog(null, "Password cannot be empty.");
            return;
        }
        users.put(username, password);
        JOptionPane.showMessageDialog(null, "Registration successful. Please login.");
    }

    private static boolean loginUser() {
        String username = JOptionPane.showInputDialog("Enter username:");
        if (username == null || username.isBlank()) {
            JOptionPane.showMessageDialog(null, "Username cannot be empty.");
            return false;
        }
        String password = JOptionPane.showInputDialog("Enter password:");
        if (password == null || password.isBlank()) {
            JOptionPane.showMessageDialog(null, "Password cannot be empty.");
            return false;
        }
        if (password.equals(users.get(username))) {
            JOptionPane.showMessageDialog(null, "Login successful. Welcome " + username + "!");
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Invalid username or password.");
            return false;
        }
    }

    private static void showMessageMenu() {
        while (true) {
            String option = JOptionPane.showInputDialog("""
                                                        Select an option:
                                                        1. Send Message
                                                        2. Show Sent Messages
                                                        3. Show Disregarded Messages
                                                        4. Display Longest Sent Message
                                                        5. Search by Message ID
                                                        6. Search Messages by Recipient
                                                        7. Delete by Hash
                                                        8. Display Sent Message Report
                                                        9. Logout""");

            if (option == null || option.equals("9")) {
                JOptionPane.showMessageDialog(null, "Logged out.");
                break;
            }

            switch (option) {
                case "1" -> {
                    Message message = new Message();
                    message.generateMessageID();

                    String recipient = JOptionPane.showInputDialog("Enter recipient's cell number (e.g. +27821234567):");
                    if (message.checkRecipientCell(recipient) != 0) {
                        JOptionPane.showMessageDialog(null, "Invalid recipient number.");
                        break;
                    }
                    message.setRecipient(recipient);

                    String msgContent = JOptionPane.showInputDialog("Enter message (max 250 chars):");
                    if (!message.checkMessageLength(msgContent)) {
                        JOptionPane.showMessageDialog(null, "Invalid message length.");
                        break;
                    }
                    message.setMessage(msgContent);

                    message.setNumMessagesSent(MessageHandler.sentMessages.size()
                            + MessageHandler.storedMessages.size()
                            + MessageHandler.disregardedMessages.size());
                    String hash = message.createMessageHash();
                    message.setMessageHash(hash);

                    String actionOption = JOptionPane.showInputDialog("""
                                                                      Choose action:
                                                                      1. Send
                                                                      2. Disregard
                                                                      3. Store""" );

                    String result = message.sentMessage(actionOption);
                    JOptionPane.showMessageDialog(null, result);

                    switch (actionOption) {
                        case "1" -> MessageHandler.addMessage(message.getMessageID(), message.getRecipient(), message.getMessage(), "sent");
                        case "2" -> MessageHandler.addMessage(message.getMessageID(), message.getRecipient(), message.getMessage(), "disregard");
                        case "3" -> {
                            MessageHandler.addMessage(message.getMessageID(), message.getRecipient(), message.getMessage(), "stored");
                            message.storeMessage();
                        }
                        default -> JOptionPane.showMessageDialog(null, "No valid action selected.");
                    }
                }

                case "2" -> {
                    if (MessageHandler.sentMessages.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No messages sent.");
                    } else {
                        StringBuilder msg = new StringBuilder("Sent Messages:\n\n");
                        for (String content : MessageHandler.sentMessages) {
                            for (var entry : MessageHandler.messageMap.entrySet()) {
                                if (entry.getValue()[1].equals(content)) {
                                    String id = entry.getKey();
                                    String recipient = entry.getValue()[0];
                                    String hash = entry.getValue()[2];
                                    msg.append("Message ID: ").append(id).append("\n")
                                            .append("Message Hash: ").append(hash).append("\n")
                                            .append("Recipient: ").append(recipient).append("\n")
                                            .append("Message: ").append(content).append("\n\n");
                                    break;
                                }
                            }
                        }
                        JOptionPane.showMessageDialog(null, msg.toString());
                    }
                }

                case "3" -> {
                    if (MessageHandler.disregardedMessages.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No disregarded messages.");
                    } else {
                        StringBuilder msg = new StringBuilder("Disregarded Messages:\n\n");
                        for (String content : MessageHandler.disregardedMessages) {
                            msg.append(content).append("\n\n");
                        }
                        JOptionPane.showMessageDialog(null, msg.toString());
                    }
                }

                case "4" -> {
                    String longest = MessageHandler.getLongestMessage();
                    if (longest.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No sent messages available.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Longest Sent Message:\n" + longest);
                    }
                }

                case "5" -> {
                    String id = JOptionPane.showInputDialog("Enter message ID to search:");
                    if (id == null || id.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No message ID entered.");
                        break;
                    }
                    String[] details = MessageHandler.searchByID(id);
                    if (details == null) {
                        JOptionPane.showMessageDialog(null, "Message ID not found.");
                    } else {
                        JOptionPane.showMessageDialog(null,
                                "Message ID: " + id + "\n" +
                                        "Recipient: " + details[0] + "\n" +
                                        "Message: " + details[1] + "\n" +
                                        "Hash: " + details[2]);
                    }
                }

                case "6" -> {
                    String recipient = JOptionPane.showInputDialog("Enter recipient number to search:");
                    if (recipient == null || recipient.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No recipient entered.");
                        break;
                    }
                    var results = MessageHandler.searchByRecipient(recipient);
                    if (results.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No messages found for recipient.");
                    } else {
                        StringBuilder msg = new StringBuilder("Messages for " + recipient + ":\n\n");
                        for (String content : results) {
                            msg.append(content).append("\n\n");
                        }
                        JOptionPane.showMessageDialog(null, msg.toString());
                    }
                }

                case "7" -> {
                    String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
                    if (hash == null || hash.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "No hash entered.");
                        break;
                    }
                    boolean success = MessageHandler.deleteByHash(hash);
                    if (success) {
                        JOptionPane.showMessageDialog(null, "Message deleted successfully.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Message with that hash not found.");
                    }
                }

                case "8" -> {
                    String report = MessageHandler.generateReport();
                    JOptionPane.showMessageDialog(null, report);
                }

                default -> JOptionPane.showMessageDialog(null, "Invalid option selected.");
            }
        }
    }
}
