import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    Login login;

    @BeforeEach
    public void setUp() {
        login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Lock");
    }

    @Test
    public void testCheckUserName_Valid() {
        assertTrue(login.checkUserName());
    }

    @Test
    public void testCheckUserName_Invalid() {
        Login invalidLogin = new Login("kyle!!!!", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Lock");
        assertFalse(invalidLogin.checkUserName());
    }

    @Test
    public void testCheckPasswordComplexity_Valid() {
        assertTrue(login.checkPasswordComplexity());
    }

    @Test
    public void testCheckPasswordComplexity_Invalid() {
        Login weakPasswordLogin = new Login("kyl_1", "password", "+27838968976", "Kyle", "Lock");
        assertFalse(weakPasswordLogin.checkPasswordComplexity());
    }

    @Test
    public void testCheckCellPhoneNumber_Valid() {
        assertTrue(login.checkCellPhoneNumber());
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid() {
        Login invalidPhoneLogin = new Login("kyl_1", "Ch&&sec@ke99!", "08966553", "Kyle", "Lock");
        assertFalse(invalidPhoneLogin.checkCellPhoneNumber());
    }

    @Test
    public void testRegisterUser_Success() {
        String expected = "User registered successfully.";
        assertEquals(expected, login.registerUser());
    }

    @Test
    public void testRegisterUser_InvalidUsername() {
        Login invalidUser = new Login("kyle!!!", "Ch&&sec@ke99!", "+27838968976", "Kyle", "Lock");
        String expected = "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        assertEquals(expected, invalidUser.registerUser());
    }

    @Test
    public void testRegisterUser_InvalidPassword() {
        Login invalidPass = new Login("kyl_1", "password", "+27838968976", "Kyle", "Lock");
        String expected = "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        assertEquals(expected, invalidPass.registerUser());
    }

    @Test
    public void testLoginUser_Success() {
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginUser_Fail() {
        assertFalse(login.loginUser("wrongUser", "wrongPassword"));
    }

    @Test
    public void testReturnLoginStatus_WithParameters_Success() {
        String expected = "Welcome Kyle, Lock it is great to see you again.";
        assertEquals(expected, login.returnLoginStatus("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testReturnLoginStatus_WithParameters_Fail() {
        String expected = "Username or password incorrect, please try again.";
        assertEquals(expected, login.returnLoginStatus("wrongUser", "wrongPass"));
    }
}
