import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

/**
 * Unit tests for MessageHandler class to verify message management functionality.
 */
public class MessageTest {

    @BeforeEach
    public void setup() {
        // Clear all relevant data structures before each test for isolation
        MessageHandler.sentMessages.clear();
        MessageHandler.storedMessages.clear();
        MessageHandler.disregardedMessages.clear();
        MessageHandler.messageMap.clear();
        MessageHandler.messageHashes.clear();
        MessageHandler.messageIDs.clear();
    }

    @Test
    public void testSentMessagesPopulated() {
        MessageHandler.addMessage("1", "+27834557896", "Did you get the cake?", "sent");
        assertEquals(1, MessageHandler.sentMessages.size(), "Sent messages should have exactly 1 message.");
    }

    @Test
    public void testLongestMessage() {
        MessageHandler.addMessage("4", "+27834567890", "It is dinner time !", "sent");
        String longest = MessageHandler.getLongestMessage();
        assertEquals("It is dinner time !", longest, "Longest message should be 'It is dinner time !'");
    }

    @Test
    public void testSearchByMessageID() {
        MessageHandler.addMessage("5", "+27838884567", "Ok, I am leaving without you.", "sent");
        String[] result = MessageHandler.searchByID("5");
        assertNotNull(result, "Search by ID should return non-null array.");
        assertEquals("Ok, I am leaving without you.", result[1], "Message content mismatch.");
    }

    @Test
    public void testSearchByRecipient() {
        MessageHandler.addMessage("6", "+27838884567", "Another message to same recipient.", "sent");
        ArrayList<String> results = MessageHandler.searchByRecipient("+27838884567");
        assertFalse(results.isEmpty(), "Search by recipient should return at least one message.");
        assertTrue(results.contains("Another message to same recipient."), "Returned messages should include the expected content.");
    }

    @Test
    public void testDeleteByHash() {
        MessageHandler.addMessage("7", "+27834567890", "Delete me", "sent");
        String[] data = MessageHandler.searchByID("7");
        assertNotNull(data, "Message should exist before deletion.");
        boolean success = MessageHandler.deleteByHash(data[2]);
        assertTrue(success, "Message should be deleted successfully.");
        assertNull(MessageHandler.searchByID("7"), "Deleted message should no longer exist.");
    }

    @Test
    public void testReadFromJSON() {
        // This test assumes the file 'MishenChatApp_1/messages.json' exists and contains a specific message
        MessageHandler.readFromJSON("MishenChatApp_1/messages.json");
        assertTrue(MessageHandler.storedMessages.contains("Stored message from JSON file."), 
                   "Stored messages should include message loaded from JSON.");
    }
}
