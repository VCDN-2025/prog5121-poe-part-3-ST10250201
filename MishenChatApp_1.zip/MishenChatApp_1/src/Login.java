public class Login {
    private final String username;
    private final String password;
    private final String cellPhoneNumber;
    private final String firstName;
    private final String lastName;

    // Constructor to initialize the Login object
    public Login(String username, String password, String cellPhoneNumber, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Check if username contains underscore and is no more than 5 characters
    public boolean checkUserName() {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    // Check password complexity: >=8 characters, at least one uppercase, one number, one special char
    public boolean checkPasswordComplexity() {
        if (password == null) return false;
        return password.length() >= 8
                && password.matches(".*[A-Z].*")   // uppercase letter
                && password.matches(".*[0-9].*")   // number
                && password.matches(".*[!@#$%^&*()].*"); // special char
    }

    // Check cell phone format: South African format +27 followed by 9 digits
    public boolean checkCellPhoneNumber() {
        if (cellPhoneNumber == null) return false;
        return cellPhoneNumber.matches("^\\+27\\d{9}$");
    }

    // Register user with validation, returns message string about success or errors
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or missing international code; please correct the number and try again.";
        }
        return "User registered successfully.";
    }

    // Check login credentials
    public boolean loginUser(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }

    // Return login status message
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Getters for first and last name
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

}
