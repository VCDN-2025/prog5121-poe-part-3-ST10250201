
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import org.json.simple.JSONObject;

public class Message {
    private String messageID;
    private String messageHash;
    private String recipient;
    private String message;
    private int numMessagesSent;

    public Message() {}

    /**
     * Check if the message ID length is at most 10 characters.
     * @return true if messageID is not null and length <= 10.
     */
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    /**
     * Validates the recipient cell number.
     * @param recipient The recipient phone number string.
     * @return 0 if valid, 1 if too long, 2 if missing '+' international code or null.
     */
    public int checkRecipientCell(String recipient) {
        if (recipient == null) return 2;
        if (recipient.length() > 13) return 1;  // supports +27 plus 9 digits max
        if (!recipient.startsWith("+")) return 2;
        return 0;
    }

    /**
     * Checks if message length is within 250 characters.
     * @param messageContent Message content string.
     * @return true if not null and length <= 250.
     */
    public boolean checkMessageLength(String messageContent) {
        return messageContent != null && messageContent.length() <= 250;
    }

    /**
     * Generates a random 10-digit numeric message ID.
     */
    public void generateMessageID() {
        Random rand = new Random();
        StringBuilder sb = new StringBuilder(10);
        for (int i = 0; i < 10; i++) {
            sb.append(rand.nextInt(10));
        }
        this.messageID = sb.toString();
    }

    /**
     * Creates a message hash string formatted as:
     * first 2 digits of messageID + ":" + numMessagesSent + ":" + firstWord + lastWord (all uppercase).
     * @return the generated hash string or empty string if invalid.
     */
    public String createMessageHash() {
        if (messageID == null || messageID.length() < 2 || message == null || message.isEmpty()) {
            return "";
        }
        String firstTwo = messageID.substring(0, 2);
        String[] words = message.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];
        return (firstTwo + ":" + numMessagesSent + ":" + firstWord + lastWord).toUpperCase();
    }

    /**
     * Processes user's message action option and returns a status message.
     * @param option the user input option ("1"=send, "2"=disregard, "3"=store).
     * @return String indicating result.
     */
    public String sentMessage(String option) {
        if (option == null) return "Invalid option selected.";
        return switch (option) {
            case "1" -> "Message successfully sent.";
            case "2" -> "Press O to delete message.";
            case "3" -> "Message successfully stored.";
            default -> "Invalid option selected.";
        };
    }

    /**
     * Displays message details nicely formatted.
     * @return formatted string with message details.
     */
    public String displayMessageDetails() {
        return "Message ID: " + messageID + "\n"
             + "Message Hash: " + messageHash + "\n"
             + "Recipient: " + recipient + "\n"
             + "Message: " + message;
    }

    /**
     * Returns the total number of messages sent.
     * @return number of messages sent.
     */
    public int returnTotalMessages() {
        return numMessagesSent;
    }

    /**
     * Stores the message details as a JSON object appended to "storedMessages.json".
     */
    public void storeMessage() {
        try {
            JSONObject json = new JSONObject();
            json.put("messageID", messageID);
            json.put("messageHash", messageHash);
            json.put("recipient", recipient);
            json.put("message", message);
            json.put("numMessagesSent", numMessagesSent);

            try (FileWriter file = new FileWriter("storedMessages.json", true)) {
                file.write(json.toJSONString() + System.lineSeparator());
            }
        } catch (IOException e) {
            System.err.println("Error storing message: " + e.getMessage());
        }
    }

    // --- Getters and Setters ---

    public String getMessageID() {
        return messageID;
    }

    public void setMessageID(String messageID) {
        this.messageID = messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public void setMessageHash(String messageHash) {
        this.messageHash = messageHash;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getNumMessagesSent() {
        return numMessagesSent;
    }

    public void setNumMessagesSent(int numMessagesSent) {
        this.numMessagesSent = numMessagesSent;
    }
}
