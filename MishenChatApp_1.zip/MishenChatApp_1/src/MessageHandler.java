import java.util.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * Handles operations on messages including storing, searching, deleting, 
 * and reporting, with SHA-256 hashing for message contents.
 */
public class MessageHandler {

    // Lists to categorize messages by status
    public static ArrayList<String> sentMessages = new ArrayList<>();
    public static ArrayList<String> disregardedMessages = new ArrayList<>();
    public static ArrayList<String> storedMessages = new ArrayList<>();

    // Lists and map for tracking message hashes, IDs, and details
    public static ArrayList<String> messageHashes = new ArrayList<>();
    public static ArrayList<String> messageIDs = new ArrayList<>();
    public static HashMap<String, String[]> messageMap = new HashMap<>();

    /**
     * Generate SHA-256 hash of a given input string.
     * @param input The string to hash.
     * @return Hexadecimal SHA-256 hash or null if algorithm not found.
     */
    public static String generateHash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            System.err.println("SHA-256 algorithm not found: " + e.getMessage());
            return null;
        }
    }

    /**
     * Adds a message with ID, recipient, content and status flag.
     * @param id Message ID.
     * @param recipient Recipient phone number.
     * @param content Message content.
     * @param flag Status flag ("sent", "stored", "disregard").
     */
    public static void addMessage(String id, String recipient, String content, String flag) {
        String hash = generateHash(content + recipient + id);
        if (hash == null) return;

        // Add hash, id and map details
        messageHashes.add(hash);
        messageIDs.add(id);
        messageMap.put(id, new String[] { recipient, content, hash });

        // Add content to corresponding list by flag (case-insensitive)
        switch (flag.toLowerCase()) {
            case "sent" -> sentMessages.add(content);
            case "stored" -> storedMessages.add(content);
            case "disregard", "disregarded" -> disregardedMessages.add(content);
            default -> disregardedMessages.add(content);
        }
    }

    /**
     * Reads messages from a JSON file and adds them as stored messages.
     * @param path File path of the JSON file.
     */
    public static void readFromJSON(String path) {
        try {
            JSONParser parser = new JSONParser();
            JSONArray messages = (JSONArray) parser.parse(new FileReader(path));
            for (Object obj : messages) {
                JSONObject message = (JSONObject) obj;
                addMessage(
                    (String) message.get("messageID"),
                    (String) message.get("recipient"),
                    (String) message.get("message"),
                    "stored"
                );
            }
        } catch (IOException | ParseException e) {
            System.out.println("Error reading JSON: " + e.getMessage());
        }
    }

    /**
     * Finds the longest message among sent messages.
     * @return The longest message string or empty string if none.
     */
    public static String getLongestMessage() {
        String longest = "";
        for (String msg : sentMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        return longest;
    }

    /**
     * Searches for message details by message ID.
     * @param id Message ID to search for.
     * @return String array with [recipient, content, hash], or null if not found.
     */
    public static String[] searchByID(String id) {
        return messageMap.getOrDefault(id, null);
    }

    /**
     * Searches all messages by a recipient phone number.
     * @param recipient Recipient phone number.
     * @return List of message contents sent to that recipient.
     */
    public static ArrayList<String> searchByRecipient(String recipient) {
        ArrayList<String> results = new ArrayList<>();
        for (String[] values : messageMap.values()) {
            if (values[0].equals(recipient)) {
                results.add(values[1]);
            }
        }
        return results;
    }

    /**
     * Deletes a message from all structures by its hash.
     * @param hash SHA-256 hash of the message content.
     * @return true if deletion succeeded, false if not found.
     */
    public static boolean deleteByHash(String hash) {
        Iterator<Map.Entry<String, String[]>> iterator = messageMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String[]> entry = iterator.next();
            if (entry.getValue()[2].equals(hash)) {
                // Remove from map and all associated lists
                iterator.remove();
                messageHashes.remove(hash);
                sentMessages.remove(entry.getValue()[1]);
                storedMessages.remove(entry.getValue()[1]);
                disregardedMessages.remove(entry.getValue()[1]);
                messageIDs.remove(entry.getKey());
                return true;
            }
        }
        return false;
    }

    /**
     * Generates a formatted report of all stored messages.
     * @return String report listing message hashes, recipients, and contents.
     */
    public static String generateReport() {
        StringBuilder report = new StringBuilder("Message Report:\n");
        for (String id : messageMap.keySet()) {
            String[] values = messageMap.get(id);
            report.append("Hash: ").append(values[2]).append("\n");
            report.append("Recipient: ").append(values[0]).append("\n");
            report.append("Message: ").append(values[1]).append("\n---\n");
        }
        return report.toString();
    }
}
